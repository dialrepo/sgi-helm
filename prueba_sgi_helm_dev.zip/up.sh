helm repo add bitnami https://charts.bitnami.com/bitnami
helm dependency update  ./charts/sgi-umbrella/
helm package  ./charts/sgi-umbrella/
minikube start --driver=docker
kubectl completion bash > ~/.bash_completions/kubectl
source ~/.bash_completions/kubectl
kubectl create namespace sgi-demo
kubectl config set-context --current --namespace=sgi-demo
helm upgrade sgi sgi-umbrella-0.1.46.tgz --install --namespace sgi-demo -f ./config/values.demo.yaml
minikube addons enable ingress
minikube dashboard


para levantar el SGI
minikube start --driver=docker
kubectl create namespace sgi-demo
kubectl config set-context --current --namespace=sgi-demo
kubectl get pod 

