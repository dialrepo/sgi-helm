Necesario tener instalado `helm`, `kubectl` y `minikube`

```
helm repo add bitnami https://charts.bitnami.com/bitnami
helm dependency update  ./charts/sgi-umbrella/
helm package  ./charts/sgi-umbrella/
minikube start --driver=docker
kubectl completion bash > ~/.bash_completions/kubectl
source ~/.bash_completions/kubectl
kubectl create namespace sgi-demo
kubectl config set-context --current --namespace=sgi-demo
helm upgrade sgi sgi-umbrella-0.1.46.tgz --install --namespace sgi-demo -f ./config/values.demo.yaml

kubectl get pods

minikube addons enable ingress

# añadir `<minikube ip> demo.hercules-sgi.local` a /etc/hosts

ngrok http http://demo.hercules-sgi.local
```

# Cambios necesarios para levantarlo

- Habilitar pod postgresql en values.yaml
- Crear usuarios de los services en postgresql ¿hay script para ello? liquibase
    ```
    kubectl port-forward sgi-postgresql-0 5432:5432 -n sgi-demo &
    ```

    **TODO: meterlo en un init script de postgresql**
    ```sql
    ALTER SYSTEM SET max_connections TO '1000';
    SELECT pg_reload_conf();

    create user auth with password 'auth'; grant create on database db to auth;
    create user usr with password 'usr'; grant create on database db to usr;
    create user eer with password 'eer'; grant create on database db to eer;
    create user eti with password 'eti'; grant create on database db to eti;
    create user csp with password 'csp'; grant create on database db to csp;
    create user pii with password 'pii'; grant create on database db to pii;
    create user rel with password 'rel'; grant create on database db to rel;
    create user tp with password 'tp'; grant create on database db to tp;
    create user rep with password 'rep'; grant create on database db to rep;
    create user com with password 'com'; grant create on database db to com;
    create user cnf with password 'cnf'; grant create on database db to cnf;
    create user prc with password 'prc'; grant create on database db to prc;
    create user sgo with password 'sgo'; grant create on database db to sgo;

    -- el schema auth NO se crea con liquibase (necesario para keycloak)
    CREATE SCHEMA AUTHORIZATION auth;


    SELECT name, setting
    FROM pg_settings 
    WHERE name = 'max_connections';
    ```