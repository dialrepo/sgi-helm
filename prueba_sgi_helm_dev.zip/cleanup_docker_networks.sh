#!/bin/bash

# Get the IDs of networks used by running containers
used_networks=$(docker ps --format '{{.ID}}' | xargs -n1 docker inspect --format '{{range .NetworkSettings.Networks}}{{.NetworkID}} {{end}}' | sort | uniq)

# Get the IDs of all networks
all_networks=$(docker network ls --format '{{.ID}}')

# Find unused networks
unused_networks=$(comm -23 <(echo "$all_networks" | sort) <(echo "$used_networks" | sort))
echo $unused_networks
for network in $unused_networks; do
  echo "Removing unused network: $network"
  docker network rm "$network"
done

echo "Cleanup complete."

